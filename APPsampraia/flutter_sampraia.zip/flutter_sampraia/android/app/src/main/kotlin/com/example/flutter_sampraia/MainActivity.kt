package com.example.flutter_sampraia

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
